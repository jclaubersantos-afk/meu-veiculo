package com.zapia.meuveiculo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_EXPORT = 2101;
    private static final int REQUEST_IMPORT = 2102;
    private static final int REQUEST_EXPORT_PDF = 2103;
    private static final String BACKUP_FILE = "meu-veiculo-backup.json";
    private WebView webView;
    private String pendingText = "";
    private String pendingName = "backup-meu-veiculo.json";
    private String pendingMime = "application/json";
    private byte[] pendingPdfBytes;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 23, 21));
        getWindow().setNavigationBarColor(Color.rgb(16, 23, 21));
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/app-shell.html");
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_EXPORT) {
            writeExport(uri);
        } else if (requestCode == REQUEST_EXPORT_PDF) {
            writeReportPdf(uri);
        } else if (requestCode == REQUEST_IMPORT) {
            readImport(uri);
        }
    }

    private void writeExport(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
            if (out == null) throw new IllegalStateException("Não foi possível abrir o destino");
            out.write(pendingText.getBytes(StandardCharsets.UTF_8));
            out.flush();
            Toast.makeText(this, "Arquivo salvo com sucesso", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível salvar o arquivo", Toast.LENGTH_LONG).show();
        }
    }

    private void writeReportPdf(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
            if (out == null || pendingPdfBytes == null) throw new IllegalStateException("Destino indisponível");
            out.write(pendingPdfBytes);
            out.flush();
            pendingPdfBytes = null;
            Toast.makeText(this, "Relatório PDF salvo com sucesso", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível salvar o relatório PDF", Toast.LENGTH_LONG).show();
        }
    }

    private void readImport(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            if (in == null) throw new IllegalStateException("Arquivo indisponível");
            byte[] bytes = new byte[8192];
            int count;
            while ((count = in.read(bytes)) != -1) buffer.write(bytes, 0, count);
            final String content = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
            webView.post(() -> webView.evaluateJavascript(
                    "window.receiveBackup(" + JSONObject.quote(content) + ")", null));
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível ler esse arquivo", Toast.LENGTH_LONG).show();
        }
    }

    private class AndroidBridge {
        @JavascriptInterface
        public synchronized void saveInternalBackup(String json) {
            try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), BACKUP_FILE))) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
            } catch (Exception ignored) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Não foi possível atualizar a cópia interna", Toast.LENGTH_SHORT).show());
            }
        }

        @JavascriptInterface
        public synchronized String readInternalBackup() {
            File file = new File(getFilesDir(), BACKUP_FILE);
            if (!file.exists()) return "";
            try (FileInputStream in = new FileInputStream(file);
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                byte[] bytes = new byte[8192];
                int count;
                while ((count = in.read(bytes)) != -1) buffer.write(bytes, 0, count);
                return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
            } catch (Exception ignored) {
                return "";
            }
        }

        @JavascriptInterface
        public void exportFile(String content, String filename, String mime) {
            pendingText = content == null ? "" : content;
            pendingName = filename == null ? "meu-veiculo-export.txt" : filename;
            pendingMime = mime == null ? "application/octet-stream" : mime;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime);
                intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                try {
                    startActivityForResult(intent, REQUEST_EXPORT);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Não foi possível abrir o seletor de arquivos", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void exportPdfBase64(String base64, String filename) {
            try {
                pendingPdfBytes = Base64.decode(base64, Base64.DEFAULT);
                pendingName = filename == null ? "relatorio-veiculo.pdf" : filename;
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/pdf");
                    intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                    try {
                        startActivityForResult(intent, REQUEST_EXPORT_PDF);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Não foi possível abrir o seletor para salvar o PDF", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Não foi possível preparar o relatório PDF", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void selectBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(intent, REQUEST_IMPORT);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Não foi possível abrir o seletor de arquivos", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("Fechar o Meu Veículo?")
                .setNegativeButton("Continuar no app", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("Fechar", (dialog, which) -> finish())
                .show();
    }
}
