'use strict';
(function(){
var TYPES=['Abastecimento','Serviço mecânico','Óleo e filtros','Lavagem','Outro'];
function $(id){return document.getElementById(id);}
function today(){var d=new Date();return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2);}
function makeId(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8);}
var db={vehicles:[],records:[]},activeVehicle='',editingRecord='',reportRows=[],hasLocalData=false;
try{var stored=localStorage.getItem('meuVeiculoDB');if(stored){var parsed=JSON.parse(stored);if(Array.isArray(parsed.vehicles)&&Array.isArray(parsed.records)){db=parsed;hasLocalData=true;}}}catch(e){}
if(!hasLocalData&&window.AndroidBridge&&AndroidBridge.readInternalBackup){try{var rawInitial=AndroidBridge.readInternalBackup();if(rawInitial){var pInitial=JSON.parse(rawInitial),dataInitial=pInitial.data||pInitial;if(Array.isArray(dataInitial.vehicles)&&Array.isArray(dataInitial.records))db=dataInitial;}}catch(e){}}
try{activeVehicle=localStorage.getItem('meuVeiculoActive')||'';}catch(e){}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function money(n){return Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});}
function kmFmt(n){return Number(n||0).toLocaleString('pt-BR')+' km';}
function dateFmt(s){if(!s)return '—';var p=s.split('-');return p.length===3?p[2]+'/'+p[1]+'/'+p[0]:s;}
function currentRecords(){return db.records.filter(function(r){return r.vehicleId===activeVehicle;});}
function activeCar(){for(var i=0;i<db.vehicles.length;i++){if(db.vehicles[i].id===activeVehicle)return db.vehicles[i];}return null;}
function save(){try{localStorage.setItem('meuVeiculoDB',JSON.stringify(db));localStorage.setItem('meuVeiculoActive',activeVehicle);}catch(e){alert('Não foi possível guardar os dados neste aparelho. Libere espaço e tente novamente.');return;}try{if(window.AndroidBridge&&AndroidBridge.saveInternalBackup)AndroidBridge.saveInternalBackup(JSON.stringify(db));}catch(e){}$('backupStatus').textContent='Cópia local atualizada · '+new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});renderAll();}
function setupSelects(){var opts=TYPES.map(function(t){return '<option>'+esc(t)+'</option>';}).join('');$('recordType').innerHTML=opts;$('recordFilter').innerHTML='<option value="">Todos os serviços</option>'+opts;$('reportFilter').innerHTML='<option value="">Todos os serviços</option>'+opts;}
function renderVehicles(){var sel=$('vehiclePick');if(!db.vehicles.length){sel.innerHTML='<option value="">Cadastre seu primeiro veículo</option>';$('vehicleInfo').textContent='Toque em “+ Veículo” para começar';sel.disabled=true;activeVehicle='';return;}sel.disabled=false;var exists=false;for(var i=0;i<db.vehicles.length;i++){if(db.vehicles[i].id===activeVehicle)exists=true;}if(!exists)activeVehicle=db.vehicles[0].id;var options=[];for(var j=0;j<db.vehicles.length;j++){var v=db.vehicles[j];options.push('<option value="'+esc(v.id)+'">'+esc(v.name)+' · '+esc(v.type)+'</option>');}sel.innerHTML=options.join('');sel.value=activeVehicle;var car=activeCar();$('vehicleInfo').textContent=[car.model,car.year,car.plate?'Placa '+car.plate:''].filter(Boolean).join(' · ');}
function recordCard(r,actions){var html='<article class="card"><div class="record-top"><div><div class="record-name">'+esc(r.type)+'</div><div class="record-date">'+dateFmt(r.date)+'</div></div><div class="record-cost">'+money(r.cost)+'</div></div><span class="type-tag">'+kmFmt(r.km)+'</span>';if(r.liters)html+=' <span class="type-tag">'+Number(r.liters).toLocaleString('pt-BR')+' L</span>';if(r.note)html+='<div class="record-meta">'+esc(r.note)+'</div>';if(actions)html+='<div class="record-actions"><button class="linkbtn" onclick="editRecord(\''+esc(r.id)+'\')">Editar</button><button class="linkbtn danger" onclick="removeRecord(\''+esc(r.id)+'\')">Excluir</button></div>';return html+'</article>';}
function renderDashboard(){var rec=currentRecords(),total=0,latest=0;for(var i=0;i<rec.length;i++){total+=Number(rec[i].cost||0);latest=Math.max(latest,Number(rec[i].km)||0);}$('totalSpend').textContent=money(total);$('latestKm').textContent=latest?kmFmt(latest):'—';$('recordCount').textContent=String(rec.length);var sorted=rec.slice().sort(function(a,b){return (b.date||'').localeCompare(a.date||'')||Number(b.km)-Number(a.km);});$('recentList').innerHTML=sorted.length?sorted.slice(0,3).map(function(r){return recordCard(r,false);}).join(''):'<div class="empty">Ainda não há registros.<br>Adicione seu primeiro abastecimento ou serviço.</div>';}
window.renderRecords=function(){var type=$('recordFilter').value;var rec=currentRecords().filter(function(r){return !type||r.type===type;}).sort(function(a,b){return (b.date||'').localeCompare(a.date||'')||Number(b.km)-Number(a.km);});$('recordList').innerHTML=rec.length?rec.map(function(r){return recordCard(r,true);}).join(''):'<div class="empty">Nenhum registro encontrado para este veículo.</div>';};
window.renderReport=function(){var from=$('fromDate').value,to=$('toDate').value,type=$('reportFilter').value;reportRows=currentRecords().filter(function(r){return (!from||r.date>=from)&&(!to||r.date<=to)&&(!type||r.type===type);}).sort(function(a,b){return (a.date||'').localeCompare(b.date||'');});var total=0,liters=0,fuel=0;for(var i=0;i<reportRows.length;i++){total+=Number(reportRows[i].cost||0);if(reportRows[i].type==='Abastecimento'){fuel++;liters+=Number(reportRows[i].liters||0);}}var counts={};for(var j=0;j<TYPES.length;j++){counts[TYPES[j]]=0;}for(var k=0;k<reportRows.length;k++){counts[reportRows[k].type]=(counts[reportRows[k].type]||0)+Number(reportRows[k].cost||0);}var breakdown=TYPES.map(function(t){return '<div class="category-row"><span>'+esc(t)+'</span><strong>'+money(counts[t])+'</strong></div>';}).join('');$('reportOutput').innerHTML='<div class="report-summary"><div class="stat"><small>Total gasto</small><strong>'+money(total)+'</strong></div><div class="stat"><small>Serviços</small><strong>'+reportRows.length+'</strong></div><div class="stat"><small>Combustível</small><strong>'+liters.toLocaleString('pt-BR',{maximumFractionDigits:2})+' L</strong></div><div class="stat"><small>Abastecimentos</small><strong>'+fuel+'</strong></div></div><div class="card"><strong>Gastos por tipo</strong>'+breakdown+'</div><div class="section-head"><h2>Itens do período</h2></div>'+(reportRows.length?reportRows.slice().reverse().map(function(r){return recordCard(r,false);}).join(''):'<div class="empty">Sem lançamentos nesse período.</div>');};
function renderAll(){renderVehicles();renderDashboard();window.renderRecords();window.renderReport();}
window.showTab=function(name){var tabs=document.querySelectorAll('.tab'),panels=document.querySelectorAll('.panel');for(var i=0;i<tabs.length;i++)tabs[i].classList.toggle('active',tabs[i].dataset.tab===name);for(var j=0;j<panels.length;j++)panels[j].classList.toggle('active',panels[j].id==='panel-'+name);if(name==='reports')window.renderReport();};
var tabButtons=document.querySelectorAll('.tab');for(var ti=0;ti<tabButtons.length;ti++){tabButtons[ti].addEventListener('click',function(){showTab(this.dataset.tab);});}
$('vehiclePick').addEventListener('change',function(){activeVehicle=$('vehiclePick').value;save();});
window.closeModal=function(id){$(id).classList.remove('show');};
window.openVehicle=function(id){var v=null;if(id){for(var i=0;i<db.vehicles.length;i++)if(db.vehicles[i].id===id)v=db.vehicles[i];}$('vehicleForm').reset();$('vehicleId').value=v?v.id:'';$('vehicleHeading').textContent=v?'Editar veículo':'Adicionar veículo';$('vehicleName').value=v?v.name:'';$('vehicleType').value=v?v.type:'Carro';$('vehicleModel').value=v?v.model||'':'';$('vehicleYear').value=v?v.year||'':'';$('vehiclePlate').value=v?v.plate||'':'';$('deleteVehicleBtn').classList.toggle('hidden',!v);$('vehicleModal').classList.add('show');};
$('vehicleForm').addEventListener('submit',function(e){e.preventDefault();var id=$('vehicleId').value,name=$('vehicleName').value.trim();if(!name)return;var obj={id:id||makeId(),name:name,type:$('vehicleType').value,model:$('vehicleModel').value.trim(),year:$('vehicleYear').value,plate:$('vehiclePlate').value.trim().toUpperCase()};if(id){db.vehicles=db.vehicles.map(function(v){return v.id===id?obj:v;});}else{db.vehicles.push(obj);activeVehicle=obj.id;}closeModal('vehicleModal');save();});
window.deleteVehicle=function(){var v=activeCar();if(!v||!confirm('Excluir '+v.name+' e todos os registros deste veículo? Essa ação não pode ser desfeita.'))return;db.vehicles=db.vehicles.filter(function(x){return x.id!==v.id;});db.records=db.records.filter(function(r){return r.vehicleId!==v.id;});activeVehicle=db.vehicles.length?db.vehicles[0].id:'';closeModal('vehicleModal');save();};
function updateFuelField(){$('litersWrap').classList.toggle('hidden',$('recordType').value!=='Abastecimento');$('recordLiters').required=$('recordType').value==='Abastecimento';}
window.openRecord=function(type){if(!activeVehicle){alert('Cadastre primeiro um veículo.');openVehicle();return;}editingRecord='';$('recordForm').reset();$('recordId').value='';$('recordHeading').textContent='Novo registro';$('recordDate').value=today();$('recordType').value=type||'Abastecimento';updateFuelField();$('recordModal').classList.add('show');};
$('recordType').addEventListener('change',updateFuelField);
window.editRecord=function(id){var r=null;for(var i=0;i<db.records.length;i++)if(db.records[i].id===id)r=db.records[i];if(!r)return;editingRecord=id;$('recordForm').reset();$('recordId').value=id;$('recordHeading').textContent='Editar registro';$('recordDate').value=r.date;$('recordType').value=r.type;$('recordKm').value=r.km;$('recordCost').value=r.cost;$('recordLiters').value=r.liters||'';$('recordNote').value=r.note||'';updateFuelField();$('recordModal').classList.add('show');};
$('recordForm').addEventListener('submit',function(e){e.preventDefault();var type=$('recordType').value,liters=$('recordLiters').value;if(type==='Abastecimento'&&(!liters||Number(liters)<=0)){alert('Informe a quantidade de litros abastecidos.');return;}var obj={id:editingRecord||makeId(),vehicleId:activeVehicle,type:type,date:$('recordDate').value,km:Number($('recordKm').value),cost:Number($('recordCost').value||0),liters:type==='Abastecimento'?Number(liters):null,note:$('recordNote').value.trim()};if(!obj.date||!isFinite(obj.km)||obj.km<0){alert('Confira a data e a quilometragem.');return;}if(editingRecord){db.records=db.records.map(function(r){return r.id===editingRecord?obj:r;});}else db.records.push(obj);closeModal('recordModal');save();});
window.removeRecord=function(id){if(!confirm('Excluir este registro?'))return;db.records=db.records.filter(function(r){return r.id!==id;});save();};
function pdfReportWinAnsi(text){
  var special={8364:128,8218:130,402:131,8222:132,8230:133,8224:134,8225:135,710:136,8240:137,352:138,8249:139,338:140,381:142,8216:145,8217:146,8220:147,8221:148,8226:149,8211:150,8212:151,732:152,8482:153,353:154,8250:155,339:156,382:158,376:159};
  var hex='',s=String(text==null?'':text);
  for(var i=0;i<s.length;i++){
    var cp=s.charCodeAt(i),b;
    if(cp>=32&&cp<=126||cp>=160&&cp<=255)b=cp;else if(special[cp]!=null)b=special[cp];else b=63;
    hex+=('0'+b.toString(16)).slice(-2);
  }
  return '<'+hex+'>';
}
function makeDarkReportPdf(data){
  var W=595,H=842, C={bg:'#101715',header:'#102d27',panel:'#19221f',panel2:'#202b27',line:'#2c3934',text:'#e8f0ec',muted:'#a0b0a8',accent:'#83d9b7'};
  function rgb(c){var n=parseInt(c.slice(1),16);return [((n>>16)&255)/255,((n>>8)&255)/255,(n&255)/255].map(function(v){return v.toFixed(3);}).join(' ');}
  function rect(a,x,y,w,h,color){a.push(rgb(color)+' rg '+x+' '+(H-y-h)+' '+w+' '+h+' re f');}
  function line(a,x1,y1,x2,y2,color,width){a.push(rgb(color)+' RG '+width+' w '+x1+' '+(H-y1)+' m '+x2+' '+(H-y2)+' l S');}
  function text(a,s,x,y,size,color,bold){a.push('BT /'+(bold?'F2':'F1')+' '+size+' Tf '+rgb(color)+' rg '+x+' '+(H-y)+' Td '+pdfReportWinAnsi(s)+' Tj ET');}
  function wrap(s,maxChars){var words=String(s||'').split(/\s+/),out=[],cur='';for(var i=0;i<words.length;i++){var next=cur?cur+' '+words[i]:words[i];if(next.length>maxChars&&cur){out.push(cur);cur=words[i];}else cur=next;}if(cur)out.push(cur);return out;}
  function pageBase(pageNo,first){var a=[];rect(a,0,0,W,H,C.bg);rect(a,0,0,W,first?121:100,C.header);rect(a,0,first?119:98,W,2,C.accent);text(a,'MEU VEÍCULO  /  RELATÓRIO',36,30,9,C.accent,true);text(a,first?'Relatório de despesas':'Relatório de despesas · continuação',36,59,22,C.text,true);text(a,data.vehicle||'Veículo não identificado',36,83,11,C.text,true);text(a,(data.period||'Todo o periodo')+'  ·  Gerado em '+(data.generated||''),36,103,9,C.muted,false);return a;}
  var pages=[],a=pageBase(1,true),y=136;
  var metrics=[['TOTAL GASTO',data.total||'R$ 0,00'],['SERVIÇOS',String(data.services||0)],['COMBUSTÍVEL',data.fuelLiters||'0 L']];
  var gap=9,cardW=(W-72-gap*2)/3;
  for(var m=0;m<metrics.length;m++){var x=36+m*(cardW+gap);rect(a,x,y,cardW,67,C.panel);text(a,metrics[m][0],x+12,y+22,8,C.muted,true);text(a,metrics[m][1],x+12,y+48,15,C.text,true);}
  text(a,'GASTOS POR TIPO',36,231,10,C.accent,true);rect(a,36,244,W-72,139,C.panel);
  var types=data.typeTotals||[];
  for(var t=0;t<types.length;t++){var ty=259+t*23;text(a,types[t].name,50,ty,9,C.text,false);text(a,types[t].total,430,ty,9,C.text,true);if(t<types.length-1)line(a,50,ty+8,W-50,ty+8,C.line,0.5);}
  text(a,'REGISTROS DO PERÍODO',36,414,10,C.accent,true);y=430;
  function finishPage(){line(a,36,806,W-36,806,C.line,0.6);text(a,'Meu Veículo  ·  Relatório em modo escuro',36,824,8,C.muted,false);text(a,'Pagina '+(pages.length+1),W-92,824,8,C.muted,false);pages.push(a.join('\n'));}
  var items=data.items||[];
  if(!items.length){rect(a,36,y,W-72,52,C.panel);text(a,'Nenhum lançamento no período selecionado.',50,y+30,10,C.muted,false);}
  for(var i=0;i<items.length;i++){
    var item=items[i],noteLines=wrap(item.note||'',84),h=58+(item.note?noteLines.length*12:0);
    if(y+h>790){finishPage();a=pageBase(pages.length+1,false);y=125;}
    rect(a,36,y,W-72,h,C.panel);rect(a,36,y,3,h,C.accent);
    text(a,item.date||'—',50,y+19,8,C.muted,false);
    text(a,item.type||'Serviço',50,y+37,11,C.text,true);
    text(a,item.cost||'R$ 0,00',415,y+29,11,C.accent,true);
    text(a,(item.km||'0 km')+(item.liters?'  ·  '+item.liters:''),50,y+52,8,C.muted,false);
    for(var n=0;n<noteLines.length;n++)text(a,noteLines[n],50,y+68+n*12,8,C.text,false);
    y+=h+8;
  }
  finishPage();
  var nPages=pages.length,objects=[];objects[1]='<< /Type /Catalog /Pages 2 0 R >>';
  var kids=[];for(var p=0;p<nPages;p++)kids.push((3+p*2)+' 0 R');
  objects[2]='<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+nPages+' >>';
  var fontRegular=3+nPages*2,fontBold=fontRegular+1;
  for(var p2=0;p2<nPages;p2++){var pageObj=3+p2*2,contentObj=pageObj+1,stream=pages[p2];objects[pageObj]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+W+' '+H+'] /Resources << /Font << /F1 '+fontRegular+' 0 R /F2 '+fontBold+' 0 R >> >> /Contents '+contentObj+' 0 R >>';objects[contentObj]='<< /Length '+stream.length+' >>\nstream\n'+stream+'\nendstream';}
  objects[fontRegular]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';objects[fontBold]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
  var pdf='%PDF-1.4\n',offsets=[0],count=fontBold;for(var o=1;o<=count;o++){offsets[o]=pdf.length;pdf+=o+' 0 obj\n'+objects[o]+'\nendobj\n';}
  var xref=pdf.length;pdf+='xref\n0 '+(count+1)+'\n0000000000 65535 f \n';for(var q=1;q<=count;q++)pdf+=('0000000000'+offsets[q]).slice(-10)+' 00000 n \n';pdf+='trailer\n<< /Size '+(count+1)+' /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF';return pdf;
}
window.exportReport=function(){
  var car=activeCar(),total=0,liters=0,fuel=0,totals={};
  for(var i=0;i<TYPES.length;i++)totals[TYPES[i]]=0;
  for(var j=0;j<reportRows.length;j++){var r=reportRows[j];total+=Number(r.cost||0);totals[r.type]=(totals[r.type]||0)+Number(r.cost||0);if(r.type==='Abastecimento'){fuel++;liters+=Number(r.liters||0);}}
  var from=$('fromDate').value,to=$('toDate').value;
  var payload={vehicle:car?[car.name,[car.model,car.year,car.plate?'Placa '+car.plate:''].filter(Boolean).join(' · ')].filter(Boolean).join('  ·  '):'Veículo não identificado',period:(from?'De '+dateFmt(from):'Início')+' até '+(to?dateFmt(to):'hoje'),generated:new Date().toLocaleString('pt-BR'),total:money(total),services:reportRows.length,fuelLiters:liters.toLocaleString('pt-BR',{maximumFractionDigits:2})+' L',typeTotals:TYPES.map(function(t){return {name:t,total:money(totals[t]||0)};}),items:reportRows.slice().reverse().map(function(r){return {date:dateFmt(r.date),type:r.type,km:kmFmt(r.km),liters:r.liters?Number(r.liters).toLocaleString('pt-BR')+' L':'',cost:money(r.cost),note:r.note||''};})};
  var pdf=makeDarkReportPdf(payload),name='relatorio-veiculo-'+today()+'.pdf';
  if(window.AndroidBridge&&AndroidBridge.exportPdfBase64){AndroidBridge.exportPdfBase64(btoa(pdf),name);return;}
  var bytes=new Uint8Array(pdf.length);for(var k=0;k<pdf.length;k++)bytes[k]=pdf.charCodeAt(k);
  var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([bytes],{type:'application/pdf'}));a.download=name;a.click();setTimeout(function(){URL.revokeObjectURL(a.href);},1500);
};
function downloadText(text,name,mime){var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:mime}));a.download=name;a.click();setTimeout(function(){URL.revokeObjectURL(a.href);},1200);}
window.exportBackup=function(){var data=JSON.stringify({format:'meu-veiculo-backup-v1',savedAt:new Date().toISOString(),data:db},null,2),name='backup-meu-veiculo-'+today()+'.json';if(window.AndroidBridge&&AndroidBridge.exportFile)AndroidBridge.exportFile(data,name,'application/json');else downloadText(data,name,'application/json;charset=utf-8');};
window.restoreBackup=function(){if(window.AndroidBridge&&AndroidBridge.selectBackup){AndroidBridge.selectBackup();return;}$('backupFile').click();};
$('backupFile').addEventListener('change',function(e){var f=e.target.files&&e.target.files[0];if(!f)return;var rd=new FileReader();rd.onload=function(){restoreData(rd.result);};rd.readAsText(f);e.target.value='';});
function restoreData(raw){try{var p=JSON.parse(raw),data=p.data||p;if(!Array.isArray(data.vehicles)||!Array.isArray(data.records))throw new Error('invalid');if(!confirm('Substituir os dados atuais pelos dados do backup?'))return;db={vehicles:data.vehicles,records:data.records};activeVehicle=db.vehicles.length?db.vehicles[0].id:'';save();alert('Backup restaurado.');}catch(e){alert('Esse arquivo não parece ser um backup válido do Meu Veículo.');}}
window.receiveBackup=function(raw){restoreData(raw);};
window.restoreInternal=function(){if(window.AndroidBridge&&AndroidBridge.readInternalBackup){var raw=AndroidBridge.readInternalBackup();if(raw)restoreData(raw);else alert('Ainda não existe uma cópia automática salva.');}else alert('A cópia automática fica disponível na versão Android. Para restaurar aqui, use “Restaurar backup”.');};
$('fromDate').value=today().slice(0,8)+'01';$('toDate').value=today();setupSelects();renderAll();if(window.AndroidBridge&&AndroidBridge.saveInternalBackup){try{AndroidBridge.saveInternalBackup(JSON.stringify(db));}catch(e){}}
})();
