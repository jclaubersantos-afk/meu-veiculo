# Meu Veículo — projeto Android

Aplicativo local para registrar abastecimentos, serviços mecânicos, troca de óleo/filtros e lavagens de vários veículos.

## Recursos

- Cadastro de carros, SUVs, picapes/caminhonetes, vans, utilitários, motos, caminhões, ônibus, motorhomes e outros.
- Histórico individual por veículo com data e hodômetro em quilômetros.
- Campos de valor, observação e litros abastecidos.
- Filtros por tipo de serviço e relatórios por período, com total de gastos e exportação CSV.
- Uso offline: telas e arquivos do app são empacotados no aplicativo; não há permissão de internet.
- Dados no armazenamento local do app e cópia JSON automática no armazenamento interno privado do Android.
- Exportação/restauração de backup em arquivo pelo seletor nativo do Android.
- Compatibilidade configurada para Android 5.0 (API 21) ou posterior.

## Gerar APK

O workflow em `.github/workflows/build-apk.yml` compila `app-debug.apk` com Android SDK no GitHub Actions e guarda o APK como artefato da execução. Para uma compilação local, é necessário JDK 17, Android SDK (API 35) e Gradle 8.9:

```sh
gradle assembleDebug
```

O arquivo gerado fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Observação sobre backup

A cópia automática fica na área privada do app. O Android apaga essa área quando o app é desinstalado; use **Exportar backup** e guarde o JSON em Downloads ou em outro local para ter uma cópia que sobreviva à desinstalação.
